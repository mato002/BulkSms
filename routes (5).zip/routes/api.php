<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\SmsController;
use App\Http\Controllers\Api\MessageController;
use App\Http\Controllers\Api\ContactController;
use App\Http\Controllers\Api\CampaignController;
use App\Http\Controllers\Api\ClientController;
use App\Http\Controllers\Api\TopupController;
use App\Http\Controllers\Monitoring\HealthCheckController;
use App\Http\Controllers\WebhookController;
use App\Http\Controllers\MpesaWebhookController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public routes
Route::get('/health', HealthCheckController::class);

// API routes with authentication
Route::middleware(['api.auth'])->group(function () {
    
    // Company-specific routes
    Route::prefix('{company_id}')->middleware(['company.auth', 'tier.rate.limit'])->group(function () {
        
        // SMS endpoints
        Route::prefix('sms')->group(function () {
            Route::post('/send', [SmsController::class, 'send']);
            Route::get('/status/{id}', [SmsController::class, 'status']);
            Route::get('/history', [SmsController::class, 'history']);
            Route::get('/statistics', [SmsController::class, 'statistics']);
        });

        // Unified messaging endpoint (sms/whatsapp/email)
        Route::post('/messages/send', [MessageController::class, 'send']);
        
        // Contact endpoints
        Route::prefix('contacts')->group(function () {
            Route::get('/', [ContactController::class, 'index']);
            Route::post('/', [ContactController::class, 'store']);
            Route::put('/{id}', [ContactController::class, 'update']);
            Route::delete('/{id}', [ContactController::class, 'destroy']);
            Route::post('/bulk-import', [ContactController::class, 'bulkImport']);
        });
        
        // Campaign endpoints
        Route::prefix('campaigns')->group(function () {
            Route::get('/', [CampaignController::class, 'index']);
            Route::post('/', [CampaignController::class, 'store']);
            Route::put('/{id}', [CampaignController::class, 'update']);
            Route::delete('/{id}', [CampaignController::class, 'destroy']);
            Route::post('/{id}/send', [CampaignController::class, 'send']);
            Route::get('/{id}/statistics', [CampaignController::class, 'statistics']);
        });
        
        // Client endpoints
        Route::prefix('client')->group(function () {
            Route::get('/profile', [ClientController::class, 'profile']);
            Route::get('/balance', [ClientController::class, 'balance']);
            Route::get('/statistics', [ClientController::class, 'statistics']);
        });

        // Analytics endpoints
        Route::prefix('analytics')->group(function () {
            Route::get('/summary', [\App\Http\Controllers\Api\AnalyticsController::class, 'summary']);
            Route::get('/daily', [\App\Http\Controllers\Api\AnalyticsController::class, 'daily']);
            Route::get('/monthly', [\App\Http\Controllers\Api\AnalyticsController::class, 'monthly']);
            Route::get('/by-channel', [\App\Http\Controllers\Api\AnalyticsController::class, 'byChannel']);
            Route::get('/wallet', [\App\Http\Controllers\Api\AnalyticsController::class, 'wallet']);
        });

        // Wallet endpoints (Onfon integration)
        Route::prefix('wallet')->group(function () {
            Route::get('/balance', [\App\Http\Controllers\Api\WalletController::class, 'balance']);
            Route::post('/sync', [\App\Http\Controllers\Api\WalletController::class, 'sync']);
            Route::post('/test-connection', [\App\Http\Controllers\Api\WalletController::class, 'testConnection']);
            Route::get('/transactions', [\App\Http\Controllers\Api\TopupController::class, 'getTransactions']);
            Route::get('/transactions/export', [\App\Http\Controllers\Api\TopupController::class, 'exportTransactionsCSV']);
            Route::post('/check-sufficient', [\App\Http\Controllers\Api\TopupController::class, 'checkSufficientBalance']);
            
            // Top-up endpoints
            Route::post('/topup', [\App\Http\Controllers\Api\TopupController::class, 'initiateTopup']);
            Route::get('/topup/{transaction_id}', [\App\Http\Controllers\Api\TopupController::class, 'checkTopupStatus']);
        });
    });
});

// Webhooks (no auth - providers will call these)
Route::post('/webhooks/onfon/inbound', [WebhookController::class, 'onfonInbound']); // Inbound SMS
Route::post('/webhooks/onfon/dlr', [WebhookController::class, 'onfonDlr']); // Delivery reports
Route::post('/webhooks/whatsapp', [WebhookController::class, 'whatsappWebhook']);
Route::post('/webhooks/email', [WebhookController::class, 'emailWebhook']);

// Payment API routes (authenticated users)
Route::middleware(['auth:sanctum'])->group(function () {
    Route::prefix('payments')->group(function () {
        // M-Pesa payment routes
        Route::post('/mpesa/initiate', [\App\Http\Controllers\PaymentController::class, 'initiateMpesaPayment']);
        Route::get('/status/{transactionId}', [\App\Http\Controllers\PaymentController::class, 'checkPaymentStatus']);
        Route::get('/transactions', [\App\Http\Controllers\PaymentController::class, 'getTransactionHistory']);
        
        // Stripe payment routes
        Route::post('/stripe/create-intent', [\App\Http\Controllers\PaymentController::class, 'createStripePaymentIntent']);
        Route::get('/stripe/publishable-key', [\App\Http\Controllers\PaymentController::class, 'getStripePublishableKey']);
    });
});

// Payment webhooks (no auth - providers will call these)
Route::prefix('mpesa')->group(function () {
    Route::post('/stk/callback', [MpesaWebhookController::class, 'callback']);
    Route::post('/c2b/confirm', [MpesaWebhookController::class, 'c2bConfirm']);
    Route::post('/c2b/validate', [MpesaWebhookController::class, 'c2bValidate']);
    Route::post('/b2c/result', [MpesaWebhookController::class, 'b2cResult']);
    Route::post('/b2c/timeout', [MpesaWebhookController::class, 'b2cTimeout']);
    Route::post('/reversal/result', [MpesaWebhookController::class, 'reversalResult']);
    Route::post('/reversal/timeout', [MpesaWebhookController::class, 'reversalTimeout']);
});

// Legacy M-Pesa webhook paths (kept for backward compatibility)
Route::post('/webhooks/mpesa/callback', [MpesaWebhookController::class, 'callback']);
Route::post('/webhooks/mpesa/timeout', [MpesaWebhookController::class, 'timeout']);
Route::post('/webhooks/stripe/webhook', [\App\Http\Controllers\PaymentController::class, 'handleStripeWebhook']);

// Local test route (no auth) to validate send flow quickly
if (app()->environment('local')) {
    Route::post('/_test/messages/send', [MessageController::class, 'send'])
        ->withoutMiddleware(['api.auth', 'company.auth']);
}

// Admin routes (PRADY_TECH / client 1 API key)
Route::middleware(['api.auth', 'admin.api'])->group(function () {
    Route::prefix('admin')->group(function () {
        Route::get('/clients', [ClientController::class, 'index']);
        Route::post('/clients', [ClientController::class, 'store']);
        Route::put('/clients/{id}', [ClientController::class, 'update']);
        Route::delete('/clients/{id}', [ClientController::class, 'destroy']);
        Route::get('/statistics', [ClientController::class, 'adminStatistics']);
        Route::post('/clients/{id}/credit', [TopupController::class, 'creditClient']);
    });
});
