@props(['id' => 'list-results'])

<turbo-frame {{ $attributes->merge(['id' => $id, 'class' => 'list-results-frame']) }}>
    {{ $slot }}
</turbo-frame>
