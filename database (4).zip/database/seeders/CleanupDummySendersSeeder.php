<?php

namespace Database\Seeders;

use App\Models\Client;
use Illuminate\Database\Seeder;

class CleanupDummySendersSeeder extends Seeder
{
    /**
     * Remove test/dummy senders (e.g. COMPANY1–COMPANY30 from ClientSeeder).
     * Keeps only PRADY_TECH and FORTRESS.
     */
    public function run(): void
    {
        $keepSenderIds = ['PRADY_TECH', 'FORTRESS'];

        $removed = Client::whereNotIn('sender_id', $keepSenderIds)->get();

        if ($removed->isEmpty()) {
            $this->command?->info('No dummy senders to remove.');
            return;
        }

        foreach ($removed as $client) {
            $this->command?->line("Removing: {$client->sender_id} ({$client->name})");
            $client->delete();
        }

        $this->command?->info("Removed {$removed->count()} sender(s). Kept: " . implode(', ', $keepSenderIds));
    }
}
