<?php

namespace Database\Seeders;

use App\Models\Channel;
use App\Models\Client;
use Illuminate\Database\Seeder;

class ProductionSendersSeeder extends Seeder
{
    public function run(): void
    {
        $onfonCredentials = [
            'api_key' => 'VKft5j+GOeSXYSlk+sADT/nx5UMVpcmengSPk9Ou4Ak=',
            'client_id' => 'e27847c1-a9fe-4eef-b60d-ddb291b175ab',
            'access_key_header' => '8oj1kheKHtCX6RiiOOI1sNS9Ir88CXnB',
        ];

        $senders = [
            [
                'id' => 1,
                'name' => 'Default Client',
                'contact' => 'admin@example.com',
                'sender_id' => 'PRADY_TECH',
                'company_name' => 'PRADY_TECH',
                'api_key' => 'ea55cb72-a734-48b2-87a6-8d0ea1d397de',
                'default_sender' => 'PRADY_TECH',
            ],
            [
                'id' => 2,
                'name' => 'Fortress Limited',
                'contact' => '254700000000',
                'sender_id' => 'FORTRESS',
                'company_name' => 'FORTRESS',
                'api_key' => 'USr4kTWk6nEcolzwiSTZJgMjZ0c4F2uh',
                'default_sender' => 'FORTRESS',
            ],
        ];

        foreach ($senders as $sender) {
            $defaultSender = $sender['default_sender'];
            unset($sender['default_sender']);

            $client = Client::updateOrCreate(
                ['id' => $sender['id']],
                array_merge($sender, [
                    'balance' => 100.00,
                    'price_per_unit' => 1.00,
                    'status' => true,
                    'tier' => 'bronze',
                    'settings' => [],
                ])
            );

            Channel::updateOrCreate(
                [
                    'client_id' => $client->id,
                    'name' => 'sms',
                    'provider' => 'onfon',
                ],
                [
                    'credentials' => array_merge($onfonCredentials, [
                        'default_sender' => $defaultSender,
                    ]),
                    'active' => true,
                ]
            );
        }
    }
}
