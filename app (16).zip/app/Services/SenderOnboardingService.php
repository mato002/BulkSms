<?php

namespace App\Services;

use App\Mail\WelcomeSenderMail;
use App\Models\Client;
use App\Services\Messaging\DTO\OutboundMessage;
use App\Services\Messaging\MessageDispatcher;
use App\Support\PhoneNumber;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class SenderOnboardingService
{
    /**
     * Send onboarding credentials to the client's contact (email or phone)
     * and to the portal user email when a dashboard account was created.
     *
     * @param  array{name: string, email: string, password: string}|null  $portalUser
     * @return array{email: bool, sms: bool, recipients: list<string>}
     */
    public function notify(Client $client, ?array $portalUser = null): array
    {
        $result = ['email' => false, 'sms' => false, 'recipients' => []];

        $contact = trim((string) $client->contact);
        $apiDocUrl = $this->apiDocumentationUrl();
        $loginUrl = $this->loginUrl();

        if ($contact !== '' && $this->looksLikeEmail($contact)) {
            if ($this->sendEmail($client, $contact, $apiDocUrl, $loginUrl, $portalUser)) {
                $result['email'] = true;
                $result['recipients'][] = $contact;
            }
        }

        if ($contact !== '' && $this->looksLikePhone($contact)) {
            if ($this->sendSms($client, $contact, $apiDocUrl, $loginUrl, $portalUser)) {
                $result['sms'] = true;
                $result['recipients'][] = $contact;
            }
        }

        if ($portalUser && $this->looksLikeEmail($portalUser['email'])) {
            $userEmail = $portalUser['email'];
            if (!in_array($userEmail, $result['recipients'], true)) {
                if ($this->sendEmail($client, $userEmail, $apiDocUrl, $loginUrl, $portalUser)) {
                    $result['email'] = true;
                    $result['recipients'][] = $userEmail;
                }
            }
        }

        return $result;
    }

    public function apiDocumentationUrl(): string
    {
        return URL::route('api.documentation', [], true);
    }

    public function loginUrl(): string
    {
        return URL::route('login', [], true);
    }

    /**
     * @return array<string, string>
     */
    public function envCredentials(Client $client): array
    {
        $baseUrl = rtrim(config('app.url'), '/');

        return [
            'APP_URL' => $baseUrl,
            'API_URL' => $baseUrl . '/api',
            'API_KEY' => $client->api_key,
            'CLIENT_ID' => (string) $client->id,
            'SENDER_ID' => $client->sender_id,
        ];
    }

    public function envBlock(Client $client): string
    {
        $lines = [];
        foreach ($this->envCredentials($client) as $key => $value) {
            $lines[] = $key . '=' . $value;
        }

        return implode("\n", $lines);
    }

    /**
     * @param  array{name: string, email: string, password: string}|null  $portalUser
     */
    private function sendEmail(
        Client $client,
        string $recipient,
        string $apiDocUrl,
        string $loginUrl,
        ?array $portalUser
    ): bool {
        try {
            Mail::to($recipient)->send(new WelcomeSenderMail(
                $client,
                $apiDocUrl,
                $loginUrl,
                $this->envCredentials($client),
                $portalUser
            ));

            return true;
        } catch (\Throwable $e) {
            Log::error('Failed to send sender onboarding email', [
                'client_id' => $client->id,
                'recipient' => $recipient,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * @param  array{name: string, email: string, password: string}|null  $portalUser
     */
    private function sendSms(
        Client $client,
        string $recipient,
        string $apiDocUrl,
        string $loginUrl,
        ?array $portalUser
    ): bool {
        $billClient = $this->resolveBillingClient();
        if (!$billClient) {
            Log::warning('Sender onboarding SMS skipped: no billing client configured', [
                'client_id' => $client->id,
            ]);

            return false;
        }

        $phone = PhoneNumber::withCountryCode($recipient);
        $messages = $this->buildSmsMessages($client, $apiDocUrl, $loginUrl, $portalUser);

        try {
            $dispatcher = app(MessageDispatcher::class);

            foreach ($messages as $body) {
                $dispatcher->dispatch(new OutboundMessage(
                    clientId: $billClient->id,
                    channel: 'sms',
                    recipient: $phone,
                    sender: $billClient->sender_id,
                    body: $body,
                    metadata: [
                        'type' => 'sender_onboarding',
                        'onboarded_client_id' => $client->id,
                    ],
                ));
            }

            return true;
        } catch (\Throwable $e) {
            Log::error('Failed to send sender onboarding SMS', [
                'client_id' => $client->id,
                'recipient' => $phone,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * @param  array{name: string, email: string, password: string}|null  $portalUser
     * @return list<string>
     */
    private function buildSmsMessages(
        Client $client,
        string $apiDocUrl,
        string $loginUrl,
        ?array $portalUser
    ): array {
        $appName = config('app.name');
        $env = $this->envCredentials($client);

        $primary = implode("\n", array_filter([
            "Welcome to {$appName}!",
            "Sender: {$client->sender_id}",
            "Client ID: {$client->id}",
            "API Key: {$client->api_key}",
            'Balance: KES ' . number_format((float) $client->balance, 2),
            "API URL: {$env['API_URL']}",
            "Docs: {$apiDocUrl}",
        ]));

        $messages = [$primary];

        if ($portalUser) {
            $messages[] = implode("\n", [
                'Dashboard login:',
                "URL: {$loginUrl}",
                "Email: {$portalUser['email']}",
                "Password: {$portalUser['password']}",
            ]);
        }

        return $messages;
    }

    private function resolveBillingClient(): ?Client
    {
        $configuredId = (int) config('sms.onboarding_bill_client_id', 0);
        if ($configuredId > 0) {
            return Client::query()
                ->where('id', $configuredId)
                ->where('status', true)
                ->first();
        }

        return Client::query()
            ->where('sender_id', 'PRADY_TECH')
            ->where('status', true)
            ->first();
    }

    private function looksLikeEmail(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    private function looksLikePhone(string $value): bool
    {
        if (str_contains($value, '@')) {
            return false;
        }

        return strlen(PhoneNumber::sanitize($value)) >= 9;
    }
}
